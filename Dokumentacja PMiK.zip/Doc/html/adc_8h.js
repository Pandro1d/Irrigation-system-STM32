var adc_8h =
[
    [ "MX_ADC_Init", "adc_8h.html#aca7f21e220653e353491bceced7c5df3", null ],
    [ "hadc", "adc_8h.html#a62fcafba91cf315db7e0e0c8f22c656f", null ]
];