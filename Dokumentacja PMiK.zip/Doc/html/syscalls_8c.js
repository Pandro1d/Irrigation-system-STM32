var syscalls_8c =
[
    [ "__attribute__", "syscalls_8c.html#af9aace1b44b73111e15aa39f06f43456", null ],
    [ "__io_getchar", "syscalls_8c.html#ad0122671640a3af49792ddaa59e8294e", null ],
    [ "__io_putchar", "syscalls_8c.html#aa53ed4b191897a1bfc205aa1da005d24", null ],
    [ "_close", "syscalls_8c.html#a5aab5e2acfd600e3667dc915a2bbc7cb", null ],
    [ "_execve", "syscalls_8c.html#ad2a07db8fdf26151eb98ba5711fad8c5", null ],
    [ "_exit", "syscalls_8c.html#abc96bd69b58b2deaddb484478d911c1b", null ],
    [ "_fork", "syscalls_8c.html#a6cb6331c9d166180903d5fb78b9c9dd7", null ],
    [ "_fstat", "syscalls_8c.html#a41eef54307912a82d20e71c3d47315aa", null ],
    [ "_getpid", "syscalls_8c.html#a945e539df8e0f66d3c73c533fe1968ee", null ],
    [ "_isatty", "syscalls_8c.html#ad3134a3dc296622b8d1c5456e481505b", null ],
    [ "_kill", "syscalls_8c.html#a062a5101199c3128edd5170f2575bb10", null ],
    [ "_link", "syscalls_8c.html#a31da4cd5328defa76a9e2246992aba12", null ],
    [ "_lseek", "syscalls_8c.html#a7a61311bdf1cb025fc07dc2bdae22ce4", null ],
    [ "_open", "syscalls_8c.html#a270c9113047edd8d64186710ad76062b", null ],
    [ "_stat", "syscalls_8c.html#a4711e961db985ed2c850a8be6597af50", null ],
    [ "_times", "syscalls_8c.html#aaf727ebf57cd64d6c58b23e6ee4a4a69", null ],
    [ "_unlink", "syscalls_8c.html#a70b2f211d665cded5637065aa2bb89dc", null ],
    [ "_wait", "syscalls_8c.html#aeef0c3372d04caa1bcc99fed2ab6ec72", null ],
    [ "initialise_monitor_handles", "syscalls_8c.html#a25c7f100d498300fff65568c2fcfe639", null ],
    [ "environ", "syscalls_8c.html#aa006daaf11f1e2e45a6ababaf463212b", null ]
];