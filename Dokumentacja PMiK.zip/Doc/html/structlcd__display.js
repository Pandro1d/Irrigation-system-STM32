var structlcd__display =
[
    [ "additionalDisplayData", "structlcd__display.html#a55e692b3c650dfe2bee742c06f4b4eb1", null ],
    [ "currentRTCDate", "structlcd__display.html#a494bc55e403d8603713c81e69be38d42", null ],
    [ "currentRTCTime", "structlcd__display.html#aa66531cc4aaba4b9d5c24cad7aa1a0bc", null ],
    [ "disp_state", "structlcd__display.html#a23ccc9a58eae7a334990b8788d4e646a", null ],
    [ "flower_disp_state", "structlcd__display.html#ab1c3030142b73833b14fb7ead9887658", null ],
    [ "flowers", "structlcd__display.html#aef086787d7f4bd822cb043f0e3799032", null ],
    [ "formDispData_ptr", "structlcd__display.html#a793acae6f53a26ce334b319f6cce2a3d", null ],
    [ "lines", "structlcd__display.html#af35b27260303e0a056febf724ab56fc2", null ],
    [ "previous_disp_state", "structlcd__display.html#ab9205c9b4b574d4312cd3b3b156ae933", null ]
];