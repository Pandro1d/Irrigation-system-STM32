var group___s_t_m32_l0xx___system___private___variables =
[
    [ "AHBPrescTable", "group___s_t_m32_l0xx___system___private___variables.html#ga6e1d9cd666f0eacbfde31e9932a93466", null ],
    [ "APBPrescTable", "group___s_t_m32_l0xx___system___private___variables.html#ga5b4f8b768465842cf854a8f993b375e9", null ],
    [ "PLLMulTable", "group___s_t_m32_l0xx___system___private___variables.html#gadab2d89c9fe6053f421278d154dcfb9d", null ],
    [ "SystemCoreClock", "group___s_t_m32_l0xx___system___private___variables.html#gaa3cd3e43291e81e795d642b79b6088e6", null ]
];