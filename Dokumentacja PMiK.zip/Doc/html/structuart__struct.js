var structuart__struct =
[
    [ "receive_itter", "structuart__struct.html#a76ef56ad24ee40059c0f898127d3f7e6", null ],
    [ "received_sign", "structuart__struct.html#aeb4e5baddf5da8747d1331a08eae14cd", null ],
    [ "sending_data_flag", "structuart__struct.html#a01c49d0e66dc66805a4bf23588ac6295", null ],
    [ "start_reading_flag", "structuart__struct.html#a5423721e42ae6a9057b47364e8263f68", null ],
    [ "UART_data_buff", "structuart__struct.html#ad69286b45d55adea08dea471faff3e13", null ]
];