var group__stm32l0xx__system =
[
    [ "STM32L0xx_System_Private_Includes", "group___s_t_m32_l0xx___system___private___includes.html", "group___s_t_m32_l0xx___system___private___includes" ],
    [ "STM32L0xx_System_Private_TypesDefinitions", "group___s_t_m32_l0xx___system___private___types_definitions.html", null ],
    [ "STM32L0xx_System_Private_Defines", "group___s_t_m32_l0xx___system___private___defines.html", null ],
    [ "STM32L0xx_System_Private_Macros", "group___s_t_m32_l0xx___system___private___macros.html", null ],
    [ "STM32L0xx_System_Private_Variables", "group___s_t_m32_l0xx___system___private___variables.html", "group___s_t_m32_l0xx___system___private___variables" ],
    [ "STM32L0xx_System_Private_FunctionPrototypes", "group___s_t_m32_l0xx___system___private___function_prototypes.html", null ],
    [ "STM32L0xx_System_Private_Functions", "group___s_t_m32_l0xx___system___private___functions.html", "group___s_t_m32_l0xx___system___private___functions" ]
];