var structflower__data =
[
    [ "flower_id", "structflower__data.html#adcbd81ae40ea28bd61434f4bc5e145e3", null ],
    [ "last_watering_time", "structflower__data.html#aa87746fb058d2524a8e6d653d14c4de2", null ],
    [ "max_sensor_data", "structflower__data.html#a594f3db7590fb1d0856885ffbb324c1a", null ],
    [ "min_sensor_data", "structflower__data.html#a5339085da48765f5d01a22a8cdea5152", null ],
    [ "moisture", "structflower__data.html#aebf882942b05d71eb0fb89a62c896f7c", null ],
    [ "Pump_GPIO_Pin", "structflower__data.html#ac6644703c73d58de463f3b09424391f7", null ],
    [ "Pump_GPIO_PORT", "structflower__data.html#a3fc3f48e8f74e7255a17fbddb99aa512", null ],
    [ "PWMchannel", "structflower__data.html#a1272fa40314188986cba95038d8f43b3", null ],
    [ "PWMtimer", "structflower__data.html#a1dce143b63ef24972230de022c95c3c1", null ],
    [ "sensor_data", "structflower__data.html#acbf331243cd664da65f9f6d9a1e3b320", null ],
    [ "was_watered_flag", "structflower__data.html#a66b28b63ce3c66addcffbb692b106fcd", null ],
    [ "watering_duration", "structflower__data.html#ae8265fd9860a71cf4ba8a47f463ec88e", null ],
    [ "watering_flag", "structflower__data.html#a7a5326edf9294dbd5659d166293fd4ec", null ],
    [ "watering_itter", "structflower__data.html#a73a8e374cba47dc981ed8db63ce67e3e", null ],
    [ "watering_time", "structflower__data.html#a7e7ba23a0fc369f34e2648d42c7afcb8", null ]
];