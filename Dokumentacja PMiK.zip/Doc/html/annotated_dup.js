var annotated_dup =
[
    [ "flower_data", "structflower__data.html", "structflower__data" ],
    [ "lcd_display", "structlcd__display.html", "structlcd__display" ],
    [ "uart_struct", "structuart__struct.html", "structuart__struct" ]
];