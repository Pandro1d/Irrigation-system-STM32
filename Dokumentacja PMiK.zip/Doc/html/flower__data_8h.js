var flower__data_8h =
[
    [ "flower_data", "structflower__data.html", "structflower__data" ],
    [ "MAX_WATERING_TIMES", "flower__data_8h.html#ac28012d5045654538e25c8e263ab43f5", null ],
    [ "NUMBER_OF_FLOWERS", "flower__data_8h.html#a9b08f0cec46c0c7d0ececeadb067798b", null ],
    [ "checkForWateringTime", "flower__data_8h.html#a40684a9a5d07f405c5669d8fcf77102d", null ],
    [ "flowersInit", "flower__data_8h.html#ab6863de2cbb24b5b5c0d6a5433aaa37d", null ],
    [ "recalibrateSensorData", "flower__data_8h.html#a722c84931a4685bade7be5a3f025108b", null ],
    [ "rescaleSensorData", "flower__data_8h.html#a6b6b4564ab67d89f12aad5d587d920d6", null ],
    [ "flowers", "flower__data_8h.html#afa89be2861e5ca8bbe483e3b9388b0f4", null ]
];