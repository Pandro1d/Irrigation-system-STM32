var searchData=
[
  ['max_5fsensor_5fdata_0',['max_sensor_data',['../structflower__data.html#a594f3db7590fb1d0856885ffbb324c1a',1,'flower_data']]],
  ['min_5fsensor_5fdata_1',['min_sensor_data',['../structflower__data.html#a5339085da48765f5d01a22a8cdea5152',1,'flower_data']]],
  ['moisture_2',['moisture',['../structflower__data.html#aebf882942b05d71eb0fb89a62c896f7c',1,'flower_data']]]
];
