var searchData=
[
  ['additionaldisplaydata_0',['additionalDisplayData',['../structlcd__display.html#a55e692b3c650dfe2bee742c06f4b4eb1',1,'lcd_display']]],
  ['ahbpresctable_1',['AHBPrescTable',['../group___s_t_m32_l0xx___system___private___variables.html#ga6e1d9cd666f0eacbfde31e9932a93466',1,'system_stm32l0xx.c']]],
  ['apbpresctable_2',['APBPrescTable',['../group___s_t_m32_l0xx___system___private___variables.html#ga5b4f8b768465842cf854a8f993b375e9',1,'system_stm32l0xx.c']]]
];
