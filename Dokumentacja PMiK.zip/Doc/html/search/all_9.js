var searchData=
[
  ['initialise_5fmonitor_5fhandles_0',['initialise_monitor_handles',['../syscalls_8c.html#a25c7f100d498300fff65568c2fcfe639',1,'syscalls.c']]],
  ['initusart_1',['initUSART',['../usart_8h.html#a4b46e2e6b871d0b0f138e61760b10fa2',1,'initUSART():&#160;usart.c'],['../usart_8c.html#a4b46e2e6b871d0b0f138e61760b10fa2',1,'initUSART():&#160;usart.c']]]
];
