var searchData=
[
  ['last_5fwatering_5ftime_0',['last_watering_time',['../structflower__data.html#aa87746fb058d2524a8e6d653d14c4de2',1,'flower_data']]],
  ['lines_1',['lines',['../structlcd__display.html#af35b27260303e0a056febf724ab56fc2',1,'lcd_display']]]
];
