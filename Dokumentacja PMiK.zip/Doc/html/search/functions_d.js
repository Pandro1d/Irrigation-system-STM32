var searchData=
[
  ['rcc_5fcrs_5firqhandler_0',['RCC_CRS_IRQHandler',['../stm32l0xx__it_8h.html#a9de046b341999fe9202ea7942985e35a',1,'RCC_CRS_IRQHandler(void):&#160;stm32l0xx_it.c'],['../stm32l0xx__it_8c.html#a9de046b341999fe9202ea7942985e35a',1,'RCC_CRS_IRQHandler(void):&#160;stm32l0xx_it.c']]],
  ['recalibratesensordata_1',['recalibrateSensorData',['../flower__data_8h.html#a722c84931a4685bade7be5a3f025108b',1,'recalibrateSensorData(struct flower_data *):&#160;flower_data.c'],['../flower__data_8c.html#a7feec3399d1914b5f0bb7ee7a40933a2',1,'recalibrateSensorData(struct flower_data *flower):&#160;flower_data.c']]],
  ['receivedata_2',['receiveData',['../usart_8c.html#a33f0cf8faae6bcb200a94322a7ebdb66',1,'usart.c']]],
  ['rescalesensordata_3',['rescaleSensorData',['../flower__data_8h.html#a6b6b4564ab67d89f12aad5d587d920d6',1,'rescaleSensorData(struct flower_data *):&#160;flower_data.c'],['../flower__data_8c.html#a285e86d34f54ae65e3eeecacfc9342bc',1,'rescaleSensorData(struct flower_data *flower):&#160;flower_data.c']]],
  ['reset_5ftime_4',['Reset_Time',['../rtc_8h.html#ac5e4983900ae58708c4f17def640b925',1,'Reset_Time(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *RtcTime):&#160;rtc.c'],['../rtc_8c.html#ac5e4983900ae58708c4f17def640b925',1,'Reset_Time(RTC_HandleTypeDef *hrtc, RTC_TimeTypeDef *RtcTime):&#160;rtc.c']]],
  ['rtc_5firqhandler_5',['RTC_IRQHandler',['../stm32l0xx__it_8h.html#ab86b9dd0d7b4eacfe38086e1fa4c2312',1,'RTC_IRQHandler(void):&#160;stm32l0xx_it.c'],['../stm32l0xx__it_8c.html#ab86b9dd0d7b4eacfe38086e1fa4c2312',1,'RTC_IRQHandler(void):&#160;stm32l0xx_it.c']]]
];
