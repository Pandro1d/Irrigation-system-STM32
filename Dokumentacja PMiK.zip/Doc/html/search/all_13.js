var searchData=
[
  ['was_5fwatered_5fflag_0',['was_watered_flag',['../structflower__data.html#a66b28b63ce3c66addcffbb692b106fcd',1,'flower_data']]],
  ['watering_5fduration_1',['watering_duration',['../structflower__data.html#ae8265fd9860a71cf4ba8a47f463ec88e',1,'flower_data']]],
  ['watering_5fflag_2',['watering_flag',['../structflower__data.html#a7a5326edf9294dbd5659d166293fd4ec',1,'flower_data']]],
  ['watering_5fitter_3',['watering_itter',['../structflower__data.html#a73a8e374cba47dc981ed8db63ce67e3e',1,'flower_data']]],
  ['watering_5fstate_4',['watering_state',['../main_8c.html#a8518859a5386aaee70d801f5769c8ebc',1,'main.c']]],
  ['watering_5ftime_5',['watering_time',['../structflower__data.html#a7e7ba23a0fc369f34e2648d42c7afcb8',1,'flower_data']]]
];
