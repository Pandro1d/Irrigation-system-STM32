var searchData=
[
  ['currentrtcdate_0',['currentRTCDate',['../structlcd__display.html#a494bc55e403d8603713c81e69be38d42',1,'lcd_display']]],
  ['currentrtctime_1',['currentRTCTime',['../structlcd__display.html#aa66531cc4aaba4b9d5c24cad7aa1a0bc',1,'lcd_display']]]
];
