var flower__data_8c =
[
    [ "checkForWateringTime", "flower__data_8c.html#a892c56a8a2a438900886c03c450c04aa", null ],
    [ "flowersInit", "flower__data_8c.html#a67ba936e33075d694aac663108668fc0", null ],
    [ "recalibrateSensorData", "flower__data_8c.html#a7feec3399d1914b5f0bb7ee7a40933a2", null ],
    [ "rescaleSensorData", "flower__data_8c.html#a285e86d34f54ae65e3eeecacfc9342bc", null ]
];