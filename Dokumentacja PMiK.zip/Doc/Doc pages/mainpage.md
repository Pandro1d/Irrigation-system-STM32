@mainpage


W projekcie będziemy realizować system automatycznego nawadniania roślin  doniczkowych. Do pobierania wody użyjemy pompki sterowanej przez 		 
mikrokontroler, którą umieścimy w pojemniku na wodę. Proces podlewania będzie cykliczny, załączany o pewnej porze, 			
ustawianej przez użytkownika. Możliwość zmiany ustawień będzie zrealizowana za pomocą połączenia Bluetooth z urządzeniem 				 
mobilnym lub też za pomocą wbudowanych w system przycisków. Do obustronnego przesyłu informacji. użyjemy również interfejsu szeregowego UART. Urządzenie ponadto będzie mierzyć wilgotność gleby oraz alarmować, gdy braknie wody w pojemniku.											 
  																		 
Autorzy:																	 
Przemysław Jóźwik													
Tomasz Petrzak												 
